#!/usr/bin/env python3
def affiche() :
    print("Hello World!")
    print("Bonjour le monde!")

def dev() :
    print("Developpeur : Jade")